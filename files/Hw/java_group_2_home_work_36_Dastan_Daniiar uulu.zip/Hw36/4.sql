create INDEX first_index ON  company(id);
create INDEX second_index ON  citizen(id, birth_date, gender);
create INDEX third_index ON city(id, population);