select * from Student

insert into Student values (98756235, 'Zakirbaev Almas');
insert into Student values (43215789, 'Dmitriy Sergeevich');											  
insert into Student values (18974586, 'Asanova Alina');
