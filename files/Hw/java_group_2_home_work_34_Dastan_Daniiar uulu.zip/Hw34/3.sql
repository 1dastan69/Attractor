create table Course(id int, name varchar(50), Description varchar(50));
create table Student(id int, Full_name varchar(50) birht_date int);
create table Course_Student(id int, Course_id int, Student_id int, Start_date date);
