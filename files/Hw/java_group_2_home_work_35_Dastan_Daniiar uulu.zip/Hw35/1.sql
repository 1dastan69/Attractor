create database Bishkek;
