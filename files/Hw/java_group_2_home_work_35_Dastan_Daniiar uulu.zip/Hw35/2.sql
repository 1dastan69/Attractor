create database Bishkek;

create table city(id int, name varchar(50), population int);
create table Company(id int, name varchar(50), city_id int);
create table citizen(id int, Full_name varchar(50), gender varchar(1), birth_date date);
